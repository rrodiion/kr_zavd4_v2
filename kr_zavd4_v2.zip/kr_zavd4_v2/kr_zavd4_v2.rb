# Запитуємо користувача ввести список слів
puts "Введіть список слів через пробіл: "
user_input = gets.chomp

# Розділяємо введений рядок на слова
words = user_input.split

# Створюємо абревіатури для кожного слова та об'єднуємо їх
abbreviations = words.map { |word| word[0].upcase }.join

# Виводимо абревіатуру
puts "Абревіатура: #{abbreviations}"
